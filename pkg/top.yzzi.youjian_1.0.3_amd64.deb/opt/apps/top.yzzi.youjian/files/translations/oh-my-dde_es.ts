<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>SystemUiPage</name>
    <message>
        <location filename="../systemuipage.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="64"/>
        <source>系统</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="85"/>
        <source>法宝-系统热区</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="100"/>
        <source>Top Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="110"/>
        <location filename="../systemuipage.ui" line="233"/>
        <location filename="../systemuipage.ui" line="281"/>
        <location filename="../systemuipage.ui" line="332"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="115"/>
        <location filename="../systemuipage.ui" line="238"/>
        <location filename="../systemuipage.ui" line="286"/>
        <location filename="../systemuipage.ui" line="337"/>
        <source>Launcher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="120"/>
        <location filename="../systemuipage.ui" line="243"/>
        <location filename="../systemuipage.ui" line="291"/>
        <location filename="../systemuipage.ui" line="342"/>
        <source>Show Desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="125"/>
        <location filename="../systemuipage.ui" line="248"/>
        <location filename="../systemuipage.ui" line="296"/>
        <location filename="../systemuipage.ui" line="347"/>
        <source>Shut Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="130"/>
        <location filename="../systemuipage.ui" line="253"/>
        <location filename="../systemuipage.ui" line="301"/>
        <location filename="../systemuipage.ui" line="352"/>
        <source>Black Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="135"/>
        <location filename="../systemuipage.ui" line="258"/>
        <location filename="../systemuipage.ui" line="306"/>
        <location filename="../systemuipage.ui" line="357"/>
        <source>Multitasking View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="151"/>
        <source>Top Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="203"/>
        <source>Lower Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="212"/>
        <source>奥义-圆角大小</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="273"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;奥义-GTK标题栏高度&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="322"/>
        <source>Lower Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="372"/>
        <source>启动器</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="393"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;奥义-图标大小&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="400"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;飞升-包名搜索&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="485"/>
        <source>程序坞</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="532"/>
        <source>法宝-模式切换</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="546"/>
        <source>时尚模式</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="551"/>
        <source>高效模式</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="556"/>
        <source>既时尚又高效模式</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="564"/>
        <source>秘笈-多屏横跳</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="602"/>
        <source>通知</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="623"/>
        <source>渡劫-关闭通知</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="650"/>
        <source>法宝-图标显示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System</source>
        <translation type="vanished">Sistema</translation>
    </message>
    <message>
        <source>Ouija-rounded corner size</source>
        <translation type="vanished">tamaño de las esquinas redondeadas</translation>
    </message>
    <message>
        <source>Starter</source>
        <translation type="vanished">Inicio</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Ouija-icon size&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Tamaño de iconos&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Soaring-Packet Name Search&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Búsqueda por nombre de paquetes&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Program Dock</source>
        <translation type="vanished">Programar Muelle</translation>
    </message>
    <message>
        <source>Mana-Mode Switching</source>
        <translation type="vanished">Cambiar de modo</translation>
    </message>
    <message>
        <source>Fashion Mode</source>
        <translation type="vanished">Modo elegante</translation>
    </message>
    <message>
        <source>Efficient mode</source>
        <translation type="vanished">Modo eficiente</translation>
    </message>
    <message>
        <source>Both stylish and efficient model</source>
        <translation type="vanished">Modo elegante y eficiente a la vez</translation>
    </message>
    <message>
        <source>Secrets - multi-screen horizontal jump</source>
        <translation type="vanished">Salto horizontal multipantalla</translation>
    </message>
    <message>
        <source>Notification</source>
        <translation type="vanished">Notificación</translation>
    </message>
    <message>
        <source>Transition-Closure notification</source>
        <translation type="vanished">Transición de cierre-notificaciones</translation>
    </message>
    <message>
        <source>Mana-icon display</source>
        <translation type="vanished">Icono de la pantalla</translation>
    </message>
    <message>
        <location filename="../systemuipage.ui" line="469"/>
        <location filename="../systemuipage.ui" line="586"/>
        <location filename="../systemuipage.ui" line="643"/>
        <location filename="../systemuipage.ui" line="670"/>
        <source>PushButton</source>
        <translation>Pulsador</translation>
    </message>
</context>
<context>
    <name>Widget</name>
    <message>
        <location filename="../widget.ui" line="20"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../widget.ui" line="83"/>
        <source>background-color:#FFFFFF</source>
        <translation>background-color:#FFFFFF</translation>
    </message>
    <message>
        <location filename="../widget.ui" line="170"/>
        <source>在河之洲</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../widget.ui" line="180"/>
        <source>桌面部件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../widget.ui" line="317"/>
        <source>右键菜单</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../widget.ui" line="348"/>
        <source>界面外观</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../widget.ui" line="549"/>
        <source>当你看到这个页面说明该功能还未能上线
什么叫成功？刘亦菲彭于晏都不能看到这个页面，而你能 (´-ωก`)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Components</source>
        <translation type="vanished">Componentes</translation>
    </message>
    <message>
        <source>Question Feedback &gt;&gt;</source>
        <translation type="vanished">Pregunta de retroalimentación &gt;&gt;</translation>
    </message>
    <message>
        <source>Right click</source>
        <translation type="vanished">Clic derecho</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation type="vanished">Apariencia</translation>
    </message>
    <message>
        <source>When you see this page means that the feature has not been able to go online 
 what do you mean by success? Liu Yifei Peng Yu Yan can not see this page, and you can (´-ωก`)</source>
        <translation type="vanished">Cuando vea esta página significa que la función no ha podido entrar en línea 
 ¿qué quiere decir el éxito? Liu Yifei Peng Yu Yan no puede ver esta página, y usted puede (&apos;-ωก`)</translation>
    </message>
    <message>
        <location filename="../widget.ui" line="214"/>
        <source>icon</source>
        <translation>icon</translation>
    </message>
    <message>
        <location filename="../widget.ui" line="243"/>
        <source>问题反馈   &gt;&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../widget.ui" line="286"/>
        <source>Oh my dde</source>
        <translation>Oh my dde</translation>
    </message>
    <message>
        <location filename="../widget.cpp" line="54"/>
        <source>Restart file manager</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>YouJianPage</name>
    <message>
        <location filename="../youjianpage.ui" line="20"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../youjianpage.ui" line="76"/>
        <source>新建文档</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.ui" line="140"/>
        <source>实用工具</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create a new document</source>
        <translation type="vanished">Crear un nuevo documento</translation>
    </message>
    <message>
        <source>Practical Tools</source>
        <translation type="vanished">Herramientas prácticas</translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="34"/>
        <source>DOC document.doc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="35"/>
        <source>DOCX document.docx</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="36"/>
        <source>PPT presentation.ppt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="37"/>
        <source>PPTX presentation.pptx</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="38"/>
        <source>XLS worksheet.xls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="39"/>
        <source>XLSX worksheetlsx</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="40"/>
        <source>PDF document.pdf</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="41"/>
        <source>TXT document.txt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="42"/>
        <source>AI image.ai</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="43"/>
        <source>SVG image.svg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="44"/>
        <source>PSD image.psd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="46"/>
        <source>Right click to refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="47"/>
        <source>Hash test</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="48"/>
        <source>Show hidden files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="49"/>
        <source>Delete completely</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="50"/>
        <source>Copy Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="51"/>
        <source>Unpack(deb) to current directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="52"/>
        <source>Refresh.desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="53"/>
        <source>Hash.desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="54"/>
        <source>Show.desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="55"/>
        <source>del.desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="56"/>
        <source>copyfilepath.desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="57"/>
        <source>unpkgdeb.desktop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youjianpage.cpp" line="133"/>
        <source>Customize File Name. Suffix</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
