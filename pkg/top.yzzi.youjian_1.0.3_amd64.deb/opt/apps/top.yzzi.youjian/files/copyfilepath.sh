#!/bin/bash
echo -n $1 | xclip -i -selection clipboard
