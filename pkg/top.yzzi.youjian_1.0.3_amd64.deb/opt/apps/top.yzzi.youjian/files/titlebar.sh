#! /usr/bin/bash

# 美化大额头
mkdir -p ~/.local/share/deepin/themes/deepin/light
cd ~/.local/share/deepin/themes/deepin/light/
touch titlebar.ini

now=`date +"%Y-%m-%d %H:%M:%S"`
cat>titlebar.ini<<EOF
# $now
[Active]
height=$1
# https://www.fontke.com/tool/rgb/e9e9e9/
#backgroundColor=#E9E9E9
# https://www.fontke.com/tool/rgb/f6f8fa/
#backgroundColor=#F6F8FA
backgroundColor=#F0F0F4

[Inactive]
height=$1
# https://www.fontke.com/tool/rgb/e3e3e3/
backgroundColor=#E3E3E3
EOF

echo -e "\e[42m $now 美化成功！注销登录后即可看到效果^_^ \e[0m"
