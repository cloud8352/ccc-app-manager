#!/bin/bash
xte 'keydown Shift_L' 'key Delete' 'keyup Shift_L'