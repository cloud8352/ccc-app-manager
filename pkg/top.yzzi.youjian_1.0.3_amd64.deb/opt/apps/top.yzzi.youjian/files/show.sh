#!/bin/bash
xte 'keydown Control_L' 'key H' 'keyup Control_L'